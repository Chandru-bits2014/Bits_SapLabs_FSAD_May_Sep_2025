package com.bits.hook.hookdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HookdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
